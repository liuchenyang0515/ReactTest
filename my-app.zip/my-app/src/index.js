import React, { Fragment } from 'react';
import ReactDOM from 'react-dom';
import { Layout } from 'antd';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import AppHeader from './components/Header';

import List from './containers/List'
import Detail from './containers/Detail'

import 'antd/dist/antd.css';
import './style.css'
const { Header, Footer, Sider, Content } = Layout;
class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <Layout style={{ minWidth: '1260px', height: '100%' }}>
          <Header className='header'>
            <AppHeader></AppHeader>
          </Header>
          <Content className='content'>
            <Switch>
              <Route path='/detail' component={Detail}></Route>
              <Route path='/:id?' component={List}></Route>
            </Switch>
          </Content>
          <Footer className="footer">@copyright lcy</Footer>
        </Layout>
      </BrowserRouter>

    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);


import React, { Component } from 'react';
import { List, Typography, Divider } from 'antd';
import axios from 'axios';



class PageList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: []
        }
    }
    render() {
        
        return (
            <List
                style={{ background: '#fff' }}
                bordered
                dataSource={this.state.data}
                renderItem={item => (
                    <List.Item>
                        <Typography.Text mark>[ITEM]</Typography.Text> {item.title}
                    </List.Item>
                )}
            />
        )
    }
    componentWillReceiveProps(nextProps) {
        console.log("==="+JSON.stringify(this.props));
        console.log(nextProps);

        
        const id = nextProps.match.params.id; // 为什么传this.props会有bug，而nextProps却正常
        axios.get('http://www.dell-lee.com/react/api/list.json?id='+id)
        .then((res)=> {
            console.log(res.data.data);
            this.setState({
                data:res.data.data
            })
        })
    }
    componentDidMount() {
        let url = 'http://www.dell-lee.com/react/api/list.json?id=';
        const id = this.props.match.params.id;
        if (id) {
            url += "?id="+id;
        }
        axios.get(url+id)
        .then((res)=> {
            console.log(res.data.data);
            this.setState({
                data:res.data.data
            })
        })
    }
}

export default PageList